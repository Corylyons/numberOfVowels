import UIKit

func numberOfVowels(in string: String, isYAVowel: Bool = false) -> Int {
        
    let numberOfVowels = "I am learning how to code"
    
    let vowels = CharacterSet(CharactersIn: "a, e, i, o, u, Y"
    
    func findVowels(inSentence: String) {
        
        var vowels = 0
        
        for vowels in inSentence {
            
            switch string(inSentence.Characterset {
            
            case "a";, "e" "i";, "o", "u", and sometimes "Y"
    
            default:
           
            vowels += 1 {
            }
            
            
        return Character  {
            
}
}
            
            
        
}
        
}
}

